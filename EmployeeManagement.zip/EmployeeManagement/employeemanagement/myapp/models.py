from django.db import models

class Employee(models.Model):
    employeeID = models.CharField(max_length=7, primary_key=True)
    name = models.CharField(max_length=100)
    position = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return self.name

class Department(models.Model):
    departmentID = models.AutoField(primary_key=True)
    departmentName = models.CharField(max_length=100)

    def __str__(self):
        return self.departmentName

class Attendance(models.Model):
    attendanceID = models.AutoField(primary_key=True)
    employee = models.ForeignKey(Employee, on_delete=models.CASCADE)
    status = models.TextField(blank=True, null=True)
    date = models.DateField(blank=True, null=True)

    def __str__(self):
        return f"Attendance {self.attendanceID} - {self.employee.name} - {self.status} - {self.date}"

# Add more models as needed by following this pattern
