# WEBSITE QUẢN LÍ NHÂN SỰ
- Link trang web: https://nhan-su.herokuapp.com/
- Tài khoản demo:
  + Admin:
    - Tài khoản: admin
    - Mật khẩu: 123
  + Manager (Trưởng phòng):
    - Tài khoản: 20001
    - Mật khẩu: 123
  + Manager accountant (trưởng phòng, kế toán):
    - Tài khoản: 20003
    - Mật khẩu: 02122000
