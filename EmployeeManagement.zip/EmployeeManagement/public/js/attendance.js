$(document).ready(function(){
    // Set tick or cross of attendance table
    $('.present').html(
        '<div class="fa fa-check"></div>'
    );

    $('.absent').html(
        '<div class="fa fa-times"></div>'
    );
});