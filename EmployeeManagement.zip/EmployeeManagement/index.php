<?php
    require_once 'mvc/Bridge.php';
    
    session_start();
    $app = new App;
?>