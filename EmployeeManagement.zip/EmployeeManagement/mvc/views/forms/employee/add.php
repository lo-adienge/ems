<div class="modal" tabindex='1' id='add-modal'>
    <div class="layer" data-open='add-modal' data-refresh='#add-employee'></div>
    <div class="modal-dialog">
        <!-- Modal header -->
        <div class="modal-header center">Create New Employee</div>
        <div class="column modal-body">
            <form action="<?php echo ROOT_LINK?>Employee/add" id="add-employee" method='POST'>
                <div class="row">
                    <div class="group-form col-2 required">
                        <label for='newEmpID' class='label-form'>MSNV <span class='required-symbol'>*</span></label>
                        <input type='text' name='employeeID' id='newEmpID' class="form-input disabled" readonly>
                    </div>
                    <div class="group-form col-2">
                        <label for='startDate' class='label-form'>Start Date <span class='required-symbol'>*</span></label>
                        <input type='date' name='startDate' id='startDate' class="form-input" required>
                    </div>
                </div>
                <div class="row">
                    <div class="group-form col-2">
                        <label for='fullName' class='label-form'>Full Name <span class='required-symbol'>*</span></label>
                        <input type='text' name='fullName' id='fullName' class="form-input" required>
                    </div>
                    <div class="group-form col-2">
                        <label for='dob' class='label-form'>Date of Birth <span class='required-symbol'>*</span></label>
                        <input type='date' name='dob' id='dob' class="form-input" required>
                    </div>
                </div>
                <div class="row">
                    <div class="group-form col-2">
                        <label for='address' class='label-form'>Address</label>
                        <input type='text' name='address' id='address' class="form-input">
                    </div>
                    <div class="group-form col-2">
                        <label for='phone' class='label-form'>Phone Number<span class='required-symbol'>*</span></label>
                        <input type='text' name='phone' id='phone' class="form-input" required>
                    </div>
                </div>
                <div class="row">
                    <div class="group-form col-2">
                        <label for='gender' class='label-form'>Gender</label>
                        <input type='text' name='gender' id='gender' class="form-input">
                    </div>
                    <div class="group-form col-2">
                        <label for='education' class='label-form'>Education</label>
                        <select id='education' name="educationID" class="form-input">
                            <option value="" default selected></option>
                            <?php foreach($data['educations'] as $columns):?>
                                <option value="<?php echo $columns['educationID']?>">
                                    <?php echo $columns['qualification']?>
                                </option>
                            <?php endforeach;?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="group-form col-2">
                        <label for='position' class='label-form'>Position <span class='required-symbol'>*</span></label>
                        <select id='position' name="positionID" class="form-input" required>
                            <option value="" default selected></option>
                            <?php foreach($data['positions'] as $columns):?>
                                <option value="<?php echo $columns['positionID']?>">
                                    <?php echo $columns['positionTitle']?>
                                </option>
                            <?php endforeach;?>
                        </select>  
                    </div>
                    <div class="group-form col-2">
                        <label for='department' class='label-form'>Department <span class='required-symbol'>*</span></label>
                        <select id='department' name="departmentID" class="form-input" required>
                            <option value="" default selected></option>
                            <?php foreach($data['departments'] as $columns):?>
                                <option value="<?php echo $columns['departmentID']?>">
                                    <?php echo $columns['departmentTitle']?>
                                </option>
                            <?php endforeach;?>
                        </select>      
                    </div>
                </div>
                <div class="row">
                    <div class="group-form col-1">
                        <label for='wage' class='label-form'>Salary <span class='required-symbol'>*</span></label>
                        <input type='text' pattern='[0-9]+' id='wage' name="wage" class="form-input" required></input>  
                    </div>
                </div>
                <div class="row wrong message" id='add-message'></div>
                <fieldset class='row'>
                    <legend class='subheader'>Creat account: </legend>
                    <div class="row center" id='typeAccount'>
                        <div class="col-3">
                            <input type='checkbox' class='typeAccount' id='manager' name='role[]' value="manager" data-position ="Trưởng phòng">
                            <label for='manager'>Head of Department</label>
                        </div>
                        <div class="col-3">
                            <input type='checkbox' class='typeAccount employee' id='accountant' name='role[]' value="accountant" data-department = 'Kế toán'>
                            <label for='accounting'>Accountant</label>
                        </div>
                        <div class="col-3">
                            <input type='checkbox' class=' typeAccount employee' id='hr' name='role[]' value="personnel" data-department = 'Nhân sự'>
                            <label for='hr'>Human Resource Officer</label>
                        </div>
                    </div>
                </fieldset>
                <div class="row center">
                    <input type="submit" class='btn-primary btn submit-btn save-btn' data-submit='add-modal' value="Thêm">
                </div>
            </form>
        </div>
    </div>
</div>